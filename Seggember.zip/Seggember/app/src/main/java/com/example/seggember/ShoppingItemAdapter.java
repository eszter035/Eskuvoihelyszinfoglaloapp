package com.example.seggember;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ShoppingItemAdapter extends RecyclerView.Adapter {
    public <ShoppingItem, FirebaseFirestore> ShoppingItemAdapter(ShopListActivity firebaseFirestoreShoppingItemShopListActivity, ArrayList<ShoppingItem> mItemsData) {

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }



    //public org.gradle.api.artifacts.repositories.ExclusiveContentRepository getFilter() {
        //return null;
    //}
}
