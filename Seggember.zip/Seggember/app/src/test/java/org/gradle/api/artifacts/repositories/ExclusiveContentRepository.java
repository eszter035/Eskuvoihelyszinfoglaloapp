package org.gradle.api.artifacts.repositories;

public class ExclusiveContentRepository {
}
